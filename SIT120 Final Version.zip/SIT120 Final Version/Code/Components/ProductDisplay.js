

app.component('product-display', {
    props: {
      premium: {
        type: Boolean,
        required: true

      }
      
    },

    template:
    /*html*/
    `<div class="product-display">
            <div class="product-container">
                <div class="product-image">
                    <img v-bind:src="image">
                </div>
                <div class="product-info">
                    <h1 style="color:#CB997E;">{{ title }}</h1>

                    

                    
                    <h2 v-if="onSale"><b>{{ saleMessage }}</b></h2>
                   
                    <h3 v-if="inStock" style="color:#81b29a;"><b>IN STOCK</b></h3>
                    <h3 v-else style="color:red;"><b> OUT OF STOCK</b></h3>
                   

                    <h3><i><b>SHIPPING: {{ shipping }} </b></i></h3>

                    
        
                     
                
                   <h4 style="color:#774936;"><b>DIMENTIONS</b></h4>

                   <ul>
                     <li v-for="detail in details"><i>{{ detail }}</i></li>
                   </ul>
           
                     
                   <h4 style="color:#774936;"> <b>AVAILABLE IN MULTIPLE COLOURS</b></h4>

                 <div 
                    v-for="(variant, index) in variants" 
                    :key="variant.id" 
                    @mouseover="updateVariant(index)" 
                    class="color-circle" 
                    :style="{ backgroundColor: variant.color }">
                  </div>
                  
                  <br>

                  <button 
                    class="button" 
                    :class="{ disabledButton: !inStock }" 
                    :disabled="!inStock" 
                    v-on:click="addToCart">
                    Add to Cart
                  </button>

                  <button 
                  class="button" 
                  :disabled="!inStock" 
                  @click="removeFromCart">
                  Remove Item
                 </button>
                  

                </div>
              </div>
              <review-list v-if="reviews.length" :reviews="reviews"></review-list>
              <review-form @review-submitted="addReview"></review-form>
            </div>`,
            

     data() {
            return {
               
                onSale: true,
                product:'YOGA MAT',
                brand: 'REEBOK',
                description: 'Designed for yoga, Pilates and general exercise, the 5mm Mat is both lightweight and rollable. Made from a malleable TPE material, the Reebok 5mm Mat gives a firm grounding without compromising on comfort, increasing stability for added traction and stronger poses.',
                
                selectedVariant: 0,
          

                details: ['Lenght: 61 CM ', 'Height:10 CM',  'Width:10 CM', ],
              
                variants: [
                  { id: 2234, color: 'Black', image: './assets/images/3.png', quantity: 75 },
                  { id: 2235, color: 'Purple ', image: './assets/images/4.png', quantity: 0 },
                ],
                reviews: []

                
    
              }
        },

        methods: {
            addToCart() {
                this.$emit('add-to-cart', this.variants[this.selectedVariant].id)
            },
            
            removeFromCart() {
                this.$emit('remove-from-cart', this.variants[this.selectedVariant].id)
            },
        
            updateVariant(index) {
                this.selectedVariant = index
            },
            addReview(review) {
              this.reviews.push(review)
            }
    
    
    
        },
        computed: {
            title() {
                return this.brand + ' ' + this.product
            },
            image() {
                return this.variants[this.selectedVariant].image
            },
            inStock() {
                return this.variants[this.selectedVariant].quantity
            },
          
            saleMessage() {
                if (this.onSale) {
                    return this.brand + ' ' + this.product + ' IS ON SALE '
                }
                return ''
        

            },
            shipping() {
              if (this.premium) {
                return 'FREE'
            }
               return 2.99
            }
        }
   })



     