app.component('review-list', {
    props: {
      reviews: {
        type: Array,
        required: true
      }
    },
    template:
    /*html*/
    `
    <div class="review-container">
    <h3>Reviews:</h3>
      <ul>
        <li v-for="(review, index) in reviews" :key="index">
          {{ review.name }} Gave This Product A Rating Of {{ review.rating }} stars
          <br/>
          <h4> Here's What {{ review.name }} Had To Say About This Product </h4>
          "{{ review.review }}"
          <br/>
          <h4> Is This Product Recommend By {{ review.name }} </h4>
           {{ review.recommend }}
         
        </li>
      </ul>
    </div>
  `
  })